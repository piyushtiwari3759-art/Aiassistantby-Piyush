// functions/api/search.js (Cloudflare Pages Function)
// Same DuckDuckGo-scraping approach as the Netlify version.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};

export async function onRequestOptions() {
  return new Response(null, { status: 204, headers: corsHeaders });
}

export async function onRequestPost(context) {
  let query;
  try {
    query = (await context.request.json()).query;
  } catch (e) {
    return respond(400, { error: "Invalid request body." });
  }
  if (!query || !query.trim()) return respond(400, { error: "Missing query." });

  try {
    const res = await fetch("https://duckduckgo.com/html/?q=" + encodeURIComponent(query), {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
      }
    });
    const html = await res.text();
    const results = parseResults(html).slice(0, 4);
    if (!results.length) {
      return respond(200, { results: [], summary: "No web results found for \"" + query + "\"." });
    }
    const summary = results
      .map(function (r, i) { return (i + 1) + ". " + r.title + " \u2014 " + r.snippet; })
      .join("\n");
    return respond(200, { results: results, summary: summary });
  } catch (err) {
    return respond(500, { error: "Search failed: " + err.message });
  }
}

function parseResults(html) {
  const results = [];
  const blockRe = /<a rel="nofollow" class="result__a"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
  let match;
  while ((match = blockRe.exec(html)) && results.length < 6) {
    results.push({ title: stripTags(match[1]), snippet: stripTags(match[2]) });
  }
  return results;
}

function stripTags(str) {
  return str
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function respond(statusCode, obj) {
  return new Response(JSON.stringify(obj), {
    status: statusCode,
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}
