// functions/api/transcribe.js (Cloudflare Pages Function)
// Same Groq Whisper transcription as the Netlify version, but uses atob() for
// base64 decoding since Workers doesn't have Node's Buffer by default.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};

export async function onRequestOptions() {
  return new Response(null, { status: 204, headers: corsHeaders });
}

export async function onRequestPost(context) {
  const apiKey = context.env.GROQ_API_KEY;
  if (!apiKey) return respond(500, { error: "GROQ_API_KEY is not set on the server." });

  let audioBase64, mimeType;
  try {
    const body = await context.request.json();
    audioBase64 = body.audioBase64;
    mimeType = body.mimeType || "audio/webm";
  } catch (e) {
    return respond(400, { error: "Invalid request body." });
  }
  if (!audioBase64) return respond(400, { error: "Missing audio data." });

  try {
    const bytes = base64ToBytes(audioBase64);
    const ext = mimeType.indexOf("mp4") !== -1 ? "mp4" : "webm";
    const blob = new Blob([bytes], { type: mimeType });

    const form = new FormData();
    form.append("file", blob, "audio." + ext);
    form.append("model", "whisper-large-v3-turbo");
    form.append("response_format", "json");

    const res = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
      method: "POST",
      headers: { "Authorization": "Bearer " + apiKey },
      body: form
    });
    const data = await res.json();
    if (!res.ok) {
      return respond(res.status, { error: (data.error && data.error.message) || "Transcription failed" });
    }
    return respond(200, { text: data.text || "" });
  } catch (err) {
    return respond(500, { error: "Transcription error: " + err.message });
  }
}

function base64ToBytes(base64) {
  const binStr = atob(base64);
  const bytes = new Uint8Array(binStr.length);
  for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
  return bytes;
}

function respond(statusCode, obj) {
  return new Response(JSON.stringify(obj), {
    status: statusCode,
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}
